# This code is part of the Ansible collection community.docker, but is an independent component.
# This particular file, and this file only, is based on the Docker SDK for Python (https://github.com/docker/docker-py/)
#
# Copyright (c) 2016-2022 Docker, Inc.
#
# It is licensed under the Apache 2.0 license (see LICENSES/Apache-2.0.txt in this collection)
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import json
import os
import shutil
import tempfile
import typing as t
import unittest
from collections.abc import Callable
from unittest import mock

from pytest import fixture, mark

from ansible_collections.community.docker.plugins.module_utils._api.utils import config


class FindConfigFileTest(unittest.TestCase):
    mkdir: Callable[[str], os.PathLike[str]]

    @fixture(autouse=True)
    def tmpdir(self, tmpdir: t.Any) -> None:
        self.mkdir = tmpdir.mkdir

    def test_find_config_fallback(self) -> None:
        tmpdir = self.mkdir("test_find_config_fallback")

        with mock.patch.dict(os.environ, {"HOME": str(tmpdir)}):
            assert config.find_config_file() is None

    def test_find_config_from_explicit_path(self) -> None:
        tmpdir = self.mkdir("test_find_config_from_explicit_path")
        config_path = tmpdir.ensure("my-config-file.json")  # type: ignore[attr-defined]

        assert config.find_config_file(str(config_path)) == str(config_path)

    def test_find_config_from_environment(self) -> None:
        tmpdir = self.mkdir("test_find_config_from_environment")
        config_path = tmpdir.ensure("config.json")  # type: ignore[attr-defined]

        with mock.patch.dict(os.environ, {"DOCKER_CONFIG": str(tmpdir)}):
            assert config.find_config_file() == str(config_path)

    @mark.skipif("sys.platform == 'win32'")
    def test_find_config_from_home_posix(self) -> None:
        tmpdir = self.mkdir("test_find_config_from_home_posix")
        config_path = tmpdir.ensure(".docker", "config.json")  # type: ignore[attr-defined]

        with mock.patch.dict(os.environ, {"HOME": str(tmpdir)}):
            assert config.find_config_file() == str(config_path)

    @mark.skipif("sys.platform == 'win32'")
    def test_find_config_from_home_legacy_name(self) -> None:
        tmpdir = self.mkdir("test_find_config_from_home_legacy_name")
        config_path = tmpdir.ensure(".dockercfg")  # type: ignore[attr-defined]

        with mock.patch.dict(os.environ, {"HOME": str(tmpdir)}):
            assert config.find_config_file() == str(config_path)

    @mark.skipif("sys.platform != 'win32'")
    def test_find_config_from_home_windows(self) -> None:
        tmpdir = self.mkdir("test_find_config_from_home_windows")
        config_path = tmpdir.ensure(".docker", "config.json")  # type: ignore[attr-defined]

        with mock.patch.dict(os.environ, {"USERPROFILE": str(tmpdir)}):
            assert config.find_config_file() == str(config_path)


class LoadConfigTest(unittest.TestCase):
    def test_load_config_no_file(self) -> None:
        folder = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, folder)
        cfg = config.load_general_config(folder)
        assert cfg is not None
        assert isinstance(cfg, dict)
        assert not cfg

    def test_load_config_custom_headers(self) -> None:
        folder = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, folder)

        dockercfg_path = os.path.join(folder, "config.json")
        config_data = {
            "HttpHeaders": {"Name": "Spike", "Surname": "Spiegel"},
        }

        with open(dockercfg_path, "wt", encoding="utf-8") as f:
            json.dump(config_data, f)

        cfg = config.load_general_config(dockercfg_path)
        assert "HttpHeaders" in cfg
        assert cfg["HttpHeaders"] == {"Name": "Spike", "Surname": "Spiegel"}

    def test_load_config_detach_keys(self) -> None:
        folder = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, folder)
        dockercfg_path = os.path.join(folder, "config.json")
        config_data = {"detachKeys": "ctrl-q, ctrl-u, ctrl-i"}
        with open(dockercfg_path, "wt", encoding="utf-8") as f:
            json.dump(config_data, f)

        cfg = config.load_general_config(dockercfg_path)
        assert cfg == config_data

    def test_load_config_from_env(self) -> None:
        folder = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, folder)
        dockercfg_path = os.path.join(folder, "config.json")
        config_data = {"detachKeys": "ctrl-q, ctrl-u, ctrl-i"}
        with open(dockercfg_path, "wt", encoding="utf-8") as f:
            json.dump(config_data, f)

        with mock.patch.dict(os.environ, {"DOCKER_CONFIG": folder}):
            cfg = config.load_general_config(None)
        assert cfg == config_data
